import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: 40 }}>
      <h1>Bienvenue sur MBC High Value Business Consulting</h1>
      <p>Votre site fonctionne !</p>
    </div>
  );
}

export default App; 