import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const AuthContext = React.createContext<any>(null);

const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
          setUser(session.user);
          setIsAdmin(session.user.user_metadata?.role === 'admin' || false);
          setupRefreshTimer(session.expires_in);
        }
      } catch (error) {
        console.error('Error getting session:', error);
      }
      setLoading(false);
    };

    getSession();
  }, []);

  const handleAuthStateChange = async (event: string, session: any) => {
    if (!session) {
      setUser(null);
      setIsAdmin(false);
    } else {
      setUser(session.user);
      setIsAdmin(session.user?.user_metadata?.role === 'admin' || false);
    }
    setLoading(false);
  };

  const setupRefreshTimer = (expiresIn: number) => {
    // Implementation of setupRefreshTimer
  };

  return (
    <AuthContext.Provider value={{ user, isAdmin, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export { AuthProvider, useAuth }; 